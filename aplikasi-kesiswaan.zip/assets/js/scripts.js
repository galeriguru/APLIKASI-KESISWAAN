/*!
 * Start Bootstrap - SB Admin v7.0.7 (https://startbootstrap.com/theme/sb-admin)
 * Copyright 2013-2023 Start Bootstrap
 * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
 */
// 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Event listener for sidebar toggle button
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            // Remove localStorage to prevent persistent state issues
            // localStorage.setItem('sb|sidebarNavigation', document.body.classList.contains('sb-sidenav-toggled')); 
        });
    }

    // Collapse responsive navbar when toggler is visible (Less critical for SB Admin, but good to have)
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    if (navbarToggler) {
        navbarToggler.addEventListener('click', () => {
            responsiveNavItems.map(function (responsiveNavItem) {
                responsiveNavItem.classList.toggle('active');
            });
        });
    }

});