<?php
require_once __DIR__ . '/../vendor/autoload.php';

// Pengaturan Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); 
define('DB_PASS', '');     
define('DB_NAME', 'db_kesiswaan');

$koneksi = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

define('BASE_URL', 'http://localhost/aplikasi-kesiswaan');
define('AMBANG_BATAS_POIN_PANGGILAN', 50);
define('WHATSAPP_API_URL', 'https://api.example.com/send_message');
define('WHATSAPP_API_KEY', 'YOUR_WHATSAPP_API_KEY'); 
define('NOTIFICATION_POIN_THRESHOLD', 1); 
define('NAMA_KEPALA_SEKOLAH', 'Dr. Asep Jaenudin, M.Pd,');
define('NIP_KEPALA_SEKOLAH', '196805121990031002');
define('NAMA_SEKOLAH_LENGKAP', 'Sekolah Kita Semua'); 
define('ALAMAT_SEKOLAH', 'Jl. Menuju Kebahagiaan yang hakiki');
define('TELEPON_SEKOLAH', '(021) 12345678');
define('KOTA_SEKOLAH', 'Kota kita semua');
define('NIP_PEMBINA', '199805121990031002');