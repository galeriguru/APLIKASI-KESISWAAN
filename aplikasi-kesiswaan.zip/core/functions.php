<?php

function is_user_logged_in() {
    return isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true;
}

function get_user_role() {
    return $_SESSION['role'] ?? null;
}

function get_user_id() {
    return $_SESSION['user_id'] ?? null;
}

function get_user_nama_lengkap() {
    return $_SESSION['nama_lengkap'] ?? null;
}

function get_bulan_indonesia($bulan_angka) {
    $nama_bulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];
    return $nama_bulan[(int)$bulan_angka] ?? '';
}

function sanitize_input($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

function create_url($action, $params = []) {
    $url = "index.php?action=" . urlencode($action);
    foreach ($params as $key => $value) {
        $url .= "&" . urlencode($key) . "=" . urlencode($value);
    }
    return $url;
}

function send_notification($phone_number, $message, $type = 'whatsapp') {
    $phone_number = preg_replace('/[^0-9]/', '', $phone_number);

    // Perbaikan untuk PHP 7.4: Gunakan strpos alih-alih str_starts_with
    if (strpos($phone_number, '62') !== 0) { // Cek apakah tidak dimulai dengan '62'
         // Hapus 0 di awal jika ada, lalu tambahkan 62
        $phone_number = '62' . ltrim($phone_number, '0');
    }

    if ($type === 'whatsapp') {
        if (!defined('WHATSAPP_API_URL') || !defined('WHATSAPP_API_KEY') || empty(WHATSAPP_API_URL) || empty(WHATSAPP_API_KEY)) {
             error_log("WHATSAPP_API_URL atau WHATSAPP_API_KEY belum dikonfigurasi.");
             return false;
         }

        $post_fields = [
            'api_key' => WHATSAPP_API_KEY,
            'to' => $phone_number,
            'message' => $message,
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, WHATSAPP_API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_fields));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($curl_error) {
             error_log("CURL Error saat mengirim notifikasi WA: " . $curl_error);
             return false;
         }

         $response_data = json_decode($response, true);
         if ($http_code >= 200 && $http_code < 300) {
             error_log("Notifikasi WA berhasil dikirim ke " . $phone_number . ". Respon: " . $response);
             return true;
         } else {
             error_log("Gagal mengirim notifikasi WA ke " . $phone_number . ". HTTP Code: " . $http_code . ". Respon: " . $response);
             return false;
         }
    }
    return false;
}

?>