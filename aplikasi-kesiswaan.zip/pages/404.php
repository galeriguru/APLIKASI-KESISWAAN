<div class="container-fluid px-4">
    <h1 class="mt-4">404 - Halaman Tidak Ditemukan</h1>
    <p>Maaf, halaman yang Anda cari tidak ada.</p>
    <a href="index.php">Kembali ke Dashboard</a>
</div>