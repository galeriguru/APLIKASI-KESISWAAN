<?php
// pages/orang_tua/dashboard.php

// Ambil user_id orang tua dari session
$user_id_ortu = $_SESSION['user_id'];

// Query untuk mengambil data siswa (anak) berdasarkan ortu_user_id
$stmt = $koneksi->prepare("SELECT s.*, k.nama_kelas, k.wali_kelas FROM siswa s JOIN kelas k ON s.kelas_id = k.id WHERE s.ortu_user_id = ?");
$stmt->bind_param("i", $user_id_ortu);
$stmt->execute();
$result = $stmt->get_result();
$data_anak = $result->fetch_assoc();
$stmt->close();

if ($data_anak) {
    // Query untuk menghitung total prestasi dan pelanggaran anak
    $total_prestasi = $koneksi->query("SELECT COUNT(*) as total FROM prestasi_siswa WHERE siswa_id = {$data_anak['id']}")->fetch_assoc()['total'];
    $total_poin_pelanggaran = $koneksi->query("SELECT SUM(jp.poin) as total FROM pelanggaran_siswa ps JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id WHERE ps.siswa_id = {$data_anak['id']}")->fetch_assoc()['total'] ?? 0;
} else {
    // Handle jika data anak tidak ditemukan
    $data_anak = ['nama_lengkap' => 'Data Anak Belum Terhubung', 'nis' => '-', 'nama_kelas' => '-', 'wali_kelas' => '-', 'alamat' => '-'];
    $total_prestasi = 0;
    $total_poin_pelanggaran = 0;
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard Orang Tua</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Selamat datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</li>
    </ol>
    <div class="alert alert-info">
        Ini adalah halaman pantauan untuk putra/putri Anda: <strong><?php echo htmlspecialchars($data_anak['nama_lengkap']); ?></strong>
    </div>

    <!-- Card Statistik -->
    <div class="row">
        <div class="col-xl-6 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <h4>Total Prestasi Anak</h4>
                    <p class="h1"><?php echo $total_prestasi; ?></p>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">Lihat Detail Prestasi</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    <h4>Total Poin Pelanggaran Anak</h4>
                    <p class="h1"><?php echo $total_poin_pelanggaran; ?></p>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">Lihat Riwayat Pelanggaran</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Informasi Detail Anak -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-user-graduate me-1"></i>
            Informasi Putra/Putri Anda
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th width="200px">NIS</th>
                    <td><?php echo htmlspecialchars($data_anak['nis']); ?></td>
                </tr>
                <tr>
                    <th>Nama Lengkap</th>
                    <td><?php echo htmlspecialchars($data_anak['nama_lengkap']); ?></td>
                </tr>
                <tr>
                    <th>Kelas</th>
                    <td><?php echo htmlspecialchars($data_anak['nama_kelas']); ?></td>
                </tr>
                <tr>
                    <th>Wali Kelas</th>
                    <td><?php echo htmlspecialchars($data_anak['wali_kelas']); ?></td>
                </tr>
                <tr>
                    <th>Alamat</th>
                    <td><?php echo htmlspecialchars($data_anak['alamat']); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>