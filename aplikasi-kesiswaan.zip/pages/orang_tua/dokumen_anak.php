<?php
// Ambil user_id orang tua dari session
$user_id_ortu = $_SESSION['user_id'];

// Query untuk mengambil data siswa (anak) berdasarkan ortu_user_id
$stmt_anak = $koneksi->prepare("SELECT id, nama_lengkap FROM siswa WHERE ortu_user_id = ?");
$stmt_anak->bind_param("i", $user_id_ortu);
$stmt_anak->execute();
$data_anak = $stmt_anak->get_result()->fetch_assoc();
$stmt_anak->close();

if (!$data_anak) {
    echo '<div class="alert alert-warning">Data anak tidak ditemukan atau belum terhubung dengan akun Anda.</div>';
    exit;
}

$siswa_id_anak = $data_anak['id'];
$nama_anak = $data_anak['nama_lengkap'];

$query = "
    SELECT ds.*, u_uploader.nama_lengkap AS nama_uploader
    FROM dokumen_siswa ds
    JOIN users u_uploader ON ds.uploaded_by_user_id = u_uploader.id
    WHERE ds.siswa_id = ?
    ORDER BY ds.created_at DESC
";
$stmt_dokumen = $koneksi->prepare($query);
$stmt_dokumen->bind_param("i", $siswa_id_anak);
$stmt_dokumen->execute();
$result = $stmt_dokumen->get_result();
$stmt_dokumen->close();
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dokumen Pengajuan Anak</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Dokumen Anak</li>
    </ol>
    
    <div class="alert alert-info">
        Ini adalah daftar dokumen/surat pengajuan yang diupload oleh putra/putri Anda: <strong><?php echo htmlspecialchars($nama_anak); ?></strong>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-file-invoice me-1"></i>
            Daftar Dokumen yang Diajukan Anak
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Upload</th>
                        <th>Judul Dokumen</th>
                        <th>Jenis Dokumen</th>
                        <th>Deskripsi</th>
                        <th>Diupload Oleh</th>
                        <th>File</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($row['judul_dokumen']); ?></td>
                            <td><?php echo htmlspecialchars($row['jenis_dokumen'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_uploader']); ?></td>
                            <td>
                                <?php if (!empty($row['file_path'])): ?>
                                    <a href="uploads/dokumen/<?php echo $row['file_path']; ?>" target="_blank" class="btn btn-primary btn-sm">Lihat</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center">Belum ada dokumen yang diupload oleh anak Anda.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>