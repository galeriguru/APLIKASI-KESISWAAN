<?php
// Ambil user_id orang tua dari session
$user_id_ortu = $_SESSION['user_id'];

// Query untuk mengambil data siswa (anak) berdasarkan ortu_user_id
$stmt_anak = $koneksi->prepare("SELECT id, nama_lengkap FROM siswa WHERE ortu_user_id = ?");
$stmt_anak->bind_param("i", $user_id_ortu);
$stmt_anak->execute();
$data_anak = $stmt_anak->get_result()->fetch_assoc();
$stmt_anak->close();

if (!$data_anak) {
    echo '<div class="alert alert-warning">Data anak tidak ditemukan atau belum terhubung dengan akun Anda.</div>';
    exit;
}

$siswa_id_anak = $data_anak['id'];
$nama_anak = $data_anak['nama_lengkap'];

$query = "
    SELECT iz.*, u_pengaju.nama_lengkap AS nama_pengaju, u_penyetuju.nama_lengkap AS nama_penyetuju
    FROM izin_siswa iz
    JOIN users u_pengaju ON iz.diajukan_oleh_user_id = u_pengaju.id
    LEFT JOIN users u_penyetuju ON iz.disetujui_oleh_user_id = u_penyetuju.id
    WHERE iz.siswa_id = ?
    ORDER BY iz.created_at DESC
";
$stmt_izin = $koneksi->prepare($query);
$stmt_izin->bind_param("i", $siswa_id_anak);
$stmt_izin->execute();
$result = $stmt_izin->get_result();
$stmt_izin->close();
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Riwayat Pengajuan Izin Anak</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Riwayat Izin Anak</li>
    </ol>
    
    <div class="alert alert-info">
        Ini adalah riwayat pengajuan izin untuk putra/putri Anda: <strong><?php echo htmlspecialchars($nama_anak); ?></strong>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-history me-1"></i>
            Daftar Izin yang Diajukan Anak
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Pengajuan</th>
                        <th>Tanggal Izin</th>
                        <th>Jenis Izin</th>
                        <th>Keterangan</th>
                        <th>Bukti</th>
                        <th>Status</th>
                        <th>Penyetuju</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                            <td>
                                <?php echo date('d-m-Y', strtotime($row['tanggal_izin_mulai'])); ?>
                                <?php echo ($row['tanggal_izin_selesai'] && $row['tanggal_izin_selesai'] != $row['tanggal_izin_mulai']) ? ' s/d ' . date('d-m-Y', strtotime($row['tanggal_izin_selesai'])) : ''; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['jenis_izin']); ?></td>
                            <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
                            <td>
                                <?php if (!empty($row['file_bukti'])): ?>
                                    <a href="uploads/izin/<?php echo $row['file_bukti']; ?>" target="_blank" class="btn btn-info btn-sm">Lihat</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge 
                                    <?php 
                                        if($row['status'] == 'Diajukan') echo 'bg-secondary';
                                        elseif($row['status'] == 'Disetujui') echo 'bg-success';
                                        elseif($row['status'] == 'Ditolak') echo 'bg-danger';
                                        else echo 'bg-warning text-dark';
                                    ?>
                                "><?php echo htmlspecialchars($row['status']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($row['nama_penyetuju'] ?? '-'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">Tidak ada riwayat pengajuan izin untuk anak Anda.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>