<?php
// Ambil semua data agenda, diurutkan berdasarkan tanggal mulai
$query = "
    SELECT ag.*, u.nama_lengkap AS nama_pembuat
    FROM agenda_kesiswaan ag
    JOIN users u ON ag.created_by_user_id = u.id
    ORDER BY ag.tanggal_mulai DESC
";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Agenda Kesiswaan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Agenda Kesiswaan</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-calendar-alt me-1"></i>
            Daftar Kegiatan Kesiswaan / OSIS
            <a href="index.php?action=tambah_agenda_kesiswaan" class="btn btn-primary btn-sm float-end">
                <i class="fas fa-plus"></i> Tambah Agenda
            </a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>Judul Kegiatan</th>
                        <th>Deskripsi</th>
                        <th>Dibuat Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['tanggal_mulai'])); ?></td>
                        <td><?php echo $row['tanggal_selesai'] ? date('d-m-Y H:i', strtotime($row['tanggal_selesai'])) : '-'; ?></td>
                        <td><?php echo htmlspecialchars($row['judul_kegiatan']); ?></td>
                        <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_pembuat']); ?></td>
                        <td>
                            <a href="index.php?action=ubah_agenda_kesiswaan&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm" title="Ubah"><i class="fas fa-edit"></i></a>
                            <a href="index.php?action=hapus_agenda_kesiswaan&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus agenda ini?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>