<?php
// PHP untuk mengambil data statistik

// Statistik Umum
$total_siswa = $koneksi->query("SELECT COUNT(id) AS total FROM siswa")->fetch_assoc()['total'];
$total_kelas = $koneksi->query("SELECT COUNT(id) AS total FROM kelas")->fetch_assoc()['total'];
$total_prestasi_tercatat = $koneksi->query("SELECT COUNT(id) AS total FROM prestasi_siswa")->fetch_assoc()['total'];
$total_pelanggaran_tercatat = $koneksi->query("SELECT COUNT(id) AS total FROM pelanggaran_siswa")->fetch_assoc()['total'];

// Grafik Siswa dengan Pelanggaran Tertinggi (Top 5)
$query_top_pelanggaran = "
    SELECT s.nama_lengkap, SUM(jp.poin) AS total_poin
    FROM pelanggaran_siswa ps
    JOIN siswa s ON ps.siswa_id = s.id
    JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id
    GROUP BY s.nama_lengkap
    ORDER BY total_poin DESC
    LIMIT 5
";
$result_top_pelanggaran = mysqli_query($koneksi, $query_top_pelanggaran);
$data_top_pelanggaran_labels = [];
$data_top_pelanggaran_values = [];
while ($row = mysqli_fetch_assoc($result_top_pelanggaran)) {
    $data_top_pelanggaran_labels[] = htmlspecialchars($row['nama_lengkap']);
    $data_top_pelanggaran_values[] = $row['total_poin'];
}

// Grafik Siswa dengan Prestasi Terbanyak (Top 5)
$query_top_prestasi = "
    SELECT s.nama_lengkap, COUNT(ps.id) AS total_prestasi
    FROM prestasi_siswa ps
    JOIN siswa s ON ps.siswa_id = s.id
    GROUP BY s.nama_lengkap
    ORDER BY total_prestasi DESC
    LIMIT 5
";
$result_top_prestasi = mysqli_query($koneksi, $query_top_prestasi);
$data_top_prestasi_labels = [];
$data_top_prestasi_values = [];
while ($row = mysqli_fetch_assoc($result_top_prestasi)) {
    $data_top_prestasi_labels[] = htmlspecialchars($row['nama_lengkap']);
    $data_top_prestasi_values[] = $row['total_prestasi'];
}

// Statistik Pelanggaran per Kelas
$query_pelanggaran_per_kelas = "
    SELECT k.nama_kelas, SUM(jp.poin) AS total_poin_kelas
    FROM pelanggaran_siswa ps
    JOIN siswa s ON ps.siswa_id = s.id
    JOIN kelas k ON s.kelas_id = k.id
    JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id
    GROUP BY k.nama_kelas
    ORDER BY total_poin_kelas DESC
";
$result_pelanggaran_per_kelas = mysqli_query($koneksi, $query_pelanggaran_per_kelas);
$data_pelanggaran_kelas_labels = [];
$data_pelanggaran_kelas_values = [];
while ($row = mysqli_fetch_assoc($result_pelanggaran_per_kelas)) {
    $data_pelanggaran_kelas_labels[] = htmlspecialchars($row['nama_kelas']);
    $data_pelanggaran_kelas_values[] = $row['total_poin_kelas'];
}

// Statistik Pelanggaran per Jenis Pelanggaran
$query_pelanggaran_per_jenis = "
    SELECT jp.nama_pelanggaran, COUNT(ps.id) AS jumlah_catatan
    FROM pelanggaran_siswa ps
    JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id
    GROUP BY jp.nama_pelanggaran
    ORDER BY jumlah_catatan DESC
";
$result_pelanggaran_per_jenis = mysqli_query($koneksi, $query_pelanggaran_per_jenis);
$data_pelanggaran_jenis_labels = [];
$data_pelanggaran_jenis_values = [];
while ($row = mysqli_fetch_assoc($result_pelanggaran_per_jenis)) {
    $data_pelanggaran_jenis_labels[] = htmlspecialchars($row['nama_pelanggaran']);
    $data_pelanggaran_jenis_values[] = $row['jumlah_catatan'];
}
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard Pembina Kesiswaan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Selamat datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</li>
    </ol>

    <!-- Kartu Statistik Umum -->
    <div class="row">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-primary text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Siswa</h5>
                    <p class="card-text h2"><?php echo $total_siswa; ?></p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-success text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Prestasi Tercatat</h5>
                    <p class="card-text h2"><?php echo $total_prestasi_tercatat; ?></p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-danger text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Pelanggaran Tercatat</h5>
                    <p class="card-text h2"><?php echo $total_pelanggaran_tercatat; ?></p>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card bg-info text-white h-100">
                <div class="card-body">
                    <h5 class="card-title">Total Kelas</h5>
                    <p class="card-text h2"><?php echo $total_kelas; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafik-Grafik -->
    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i>
                    Siswa dengan Poin Pelanggaran Tertinggi
                </div>
                <div class="card-body"><canvas id="chartPelanggaranTertinggi" width="100%" height="40"></canvas></div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i>
                    Siswa dengan Prestasi Terbanyak
                </div>
                <div class="card-body"><canvas id="chartPrestasiTerbanyak" width="100%" height="40"></canvas></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-area me-1"></i>
                    Total Poin Pelanggaran per Kelas
                </div>
                <div class="card-body"><canvas id="chartPelanggaranPerKelas" width="100%" height="40"></canvas></div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-pie me-1"></i>
                    Distribusi Jenis Pelanggaran
                </div>
                <div class="card-body"><canvas id="chartPelanggaranPerJenis" width="100%" height="40"></canvas></div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Data untuk Chart.js
    const dataPelanggaranTertinggi = {
        labels: <?php echo json_encode($data_top_pelanggaran_labels); ?>,
        datasets: [{
            label: 'Total Poin',
            backgroundColor: 'rgba(220, 53, 69, 0.7)', // Merah
            borderColor: 'rgba(220, 53, 69, 1)',
            data: <?php echo json_encode($data_top_pelanggaran_values); ?>
        }]
    };

    const dataPrestasiTerbanyak = {
        labels: <?php echo json_encode($data_top_prestasi_labels); ?>,
        datasets: [{
            label: 'Jumlah Prestasi',
            backgroundColor: 'rgba(40, 167, 69, 0.7)', // Hijau
            borderColor: 'rgba(40, 167, 69, 1)',
            data: <?php echo json_encode($data_top_prestasi_values); ?>
        }]
    };

    const dataPelanggaranPerKelas = {
        labels: <?php echo json_encode($data_pelanggaran_kelas_labels); ?>,
        datasets: [{
            label: 'Total Poin Pelanggaran',
            backgroundColor: 'rgba(0, 123, 255, 0.7)', // Biru
            borderColor: 'rgba(0, 123, 255, 1)',
            data: <?php echo json_encode($data_pelanggaran_kelas_values); ?>
        }]
    };

    const dataPelanggaranPerJenis = {
        labels: <?php echo json_encode($data_pelanggaran_jenis_labels); ?>,
        datasets: [{
            data: <?php echo json_encode($data_pelanggaran_jenis_values); ?>,
            backgroundColor: [
                '#dc3545', '#ffc107', '#17a2b8', '#6610f2', '#fd7e14', '#20c997', '#e83e8c', '#6f42c1', '#f0ad4e', '#5bc0de'
            ], // Warna acak untuk setiap slice
            hoverBackgroundColor: [
                '#c82333', '#e0a800', '#138496', '#5a0ee0', '#e06b0d', '#1aaa85', '#d4307a', '#5f37af', '#e69f00', '#4aaddc'
            ]
        }]
    };

    // Opsi Global (Opsional, untuk konsistensi)
    Chart.defaults.font.family = 'Nunito,-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.font.color = '#858796';

    // Inisialisasi Chart
    if (document.getElementById('chartPelanggaranTertinggi')) {
        new Chart(document.getElementById('chartPelanggaranTertinggi'), {
            type: 'bar',
            data: dataPelanggaranTertinggi,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { beginAtZero: true } },
                    y: { beginAtZero: true }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    if (document.getElementById('chartPrestasiTerbanyak')) {
        new Chart(document.getElementById('chartPrestasiTerbanyak'), {
            type: 'bar',
            data: dataPrestasiTerbanyak,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { beginAtZero: true } },
                    y: { beginAtZero: true }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    if (document.getElementById('chartPelanggaranPerKelas')) {
        new Chart(document.getElementById('chartPelanggaranPerKelas'), {
            type: 'bar',
            data: dataPelanggaranPerKelas,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: { ticks: { beginAtZero: true } },
                    y: { beginAtZero: true }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    }

    if (document.getElementById('chartPelanggaranPerJenis')) {
        new Chart(document.getElementById('chartPelanggaranPerJenis'), {
            type: 'pie',
            data: dataPelanggaranPerJenis,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
    }
});
</script>