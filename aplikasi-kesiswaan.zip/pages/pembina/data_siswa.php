<?php
// Ambil semua data siswa dengan join ke tabel kelas
$query = "SELECT s.*, k.nama_kelas FROM siswa s JOIN kelas k ON s.kelas_id = k.id ORDER BY k.nama_kelas, s.nama_lengkap";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Data Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Data Siswa</li>
    </ol>

    <?php if (isset($_GET['status'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
                if ($_GET['status'] == 'sukses_tambah') echo "Data siswa berhasil ditambahkan!";
                if ($_GET['status'] == 'sukses_ubah') echo "Data siswa berhasil diubah!";
                if ($_GET['status'] == 'sukses_hapus') echo "Data siswa berhasil dihapus!";
                if ($_GET['status'] == 'sukses_impor') echo "Impor data siswa berhasil!";
                // Menggunakan substr() untuk kompatibilitas dengan PHP 7
                if (substr($_GET['status'], 0, 5) === 'gagal') echo "Terjadi kesalahan. Aksi gagal diproses.";
                if ($_GET['status'] == 'impor_warning') echo "Impor selesai dengan beberapa peringatan: " . htmlspecialchars($_GET['message']);
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Daftar Siswa
            <div class="float-end">
                <a href="assets/template_import_siswa.xlsx" class="btn btn-success btn-sm" download>
                    <i class="fas fa-file-excel"></i> Download Template
                </a>
                <button type="button" class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#importModal">
                    <i class="fas fa-upload"></i> Impor Excel
                </button>
                <a href="index.php?action=tambah_siswa" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Tambah Siswa
                </a>
            </div>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Lengkap</th>
                        <th>Kelas</th>
                        <th>No. Telepon</th>
                        <th>QR Code</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nis']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td><?php echo htmlspecialchars($row['no_telepon']); ?></td>
                        <td>
                            <button type="button" class="btn btn-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#qrCodeModal" data-siswa-id="<?php echo $row['id']; ?>" data-siswa-name="<?php echo htmlspecialchars($row['nama_lengkap']); ?>">
                                <i class="fas fa-qrcode"></i> Lihat QR
                            </button>
                        </td>
                        <td>
                            <a href="index.php?action=ubah_siswa&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm" title="Ubah"><i class="fas fa-edit"></i></a>
                            <a href="index.php?action=hapus_siswa&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('PERINGATAN: Menghapus data ini akan menghapus data siswa, akun login siswa, dan akun login orang tua yang terhubung. Apakah Anda yakin?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Impor Excel -->
<div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="importModalLabel">Impor Data Siswa dari Excel</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="index.php?action=proses_impor_siswa" method="POST" enctype="multipart/form-data">
          <div class="modal-body">
            <p>Pastikan file Excel Anda sesuai dengan template yang disediakan. Kolom 'Nama Kelas' harus diisi dengan nama kelas yang ada di sistem.</p>
            <div class="mb-3">
                <label for="file_excel" class="form-label">Pilih File Excel (.xlsx)</label>
                <input class="form-control" type="file" id="file_excel" name="file_excel" accept=".xlsx" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary">Upload dan Impor</button>
          </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal QR Code (existing) -->
<div class="modal fade" id="qrCodeModal" tabindex="-1" aria-labelledby="qrCodeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="qrCodeModalLabel">QR Code Rekap Kesiswaan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <p>Scan QR Code di bawah untuk melihat rekap prestasi dan pelanggaran <strong id="qr_siswa_name"></strong>:</p>
        <div id="qrCodeContainer">
            <img id="qrCodeImage" src="" alt="QR Code" class="img-fluid" style="max-width: 250px;">
        </div>
        <p class="mt-3 text-muted">Akses publik, tidak memerlukan login.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var qrCodeModal = document.getElementById('qrCodeModal');
    if (qrCodeModal) {
        qrCodeModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget; // Button that triggered the modal
            var siswaId = button.getAttribute('data-siswa-id');
            var siswaName = button.getAttribute('data-siswa-name');
            
            var modalTitle = qrCodeModal.querySelector('#qr_siswa_name');
            var qrCodeImage = qrCodeModal.querySelector('#qrCodeImage');

            modalTitle.textContent = siswaName;
            // Set the image src to the QR code generation endpoint
            qrCodeImage.src = 'index.php?action=generate_qr_code&siswa_id=' + siswaId;
        });
    }
});
</script>