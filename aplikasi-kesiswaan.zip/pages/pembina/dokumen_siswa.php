<?php
$query = "
    SELECT ds.*, s.nis, s.nama_lengkap AS nama_siswa, k.nama_kelas,
           u_uploader.nama_lengkap AS nama_uploader
    FROM dokumen_siswa ds
    JOIN siswa s ON ds.siswa_id = s.id
    JOIN kelas k ON s.kelas_id = k.id
    JOIN users u_uploader ON ds.uploaded_by_user_id = u_uploader.id
    ORDER BY ds.created_at DESC
";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Dokumen Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Manajemen Dokumen Siswa</li>
    </ol>
    
    <?php if (isset($_GET['status'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
                if ($_GET['status'] == 'sukses_hapus_dokumen') echo "Dokumen berhasil dihapus!";
                if (str_starts_with($_GET['status'], 'gagal')) echo "Terjadi kesalahan. Aksi gagal diproses.";
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-file-invoice me-1"></i>
            Daftar Dokumen/Surat Pengajuan Siswa
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Upload</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Judul Dokumen</th>
                        <th>Jenis Dokumen</th>
                        <th>Deskripsi</th>
                        <th>Diupload Oleh</th>
                        <th>File</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($row['nis']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td><?php echo htmlspecialchars($row['judul_dokumen']); ?></td>
                        <td><?php echo htmlspecialchars($row['jenis_dokumen'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_uploader']); ?></td>
                        <td>
                            <?php if (!empty($row['file_path'])): ?>
                                <a href="uploads/dokumen/<?php echo $row['file_path']; ?>" target="_blank" class="btn btn-primary btn-sm">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="index.php?action=hapus_dokumen&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus dokumen ini?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>