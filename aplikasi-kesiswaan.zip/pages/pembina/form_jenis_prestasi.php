<?php
$is_edit = isset($_GET['id']);
$id_jenis = $is_edit ? $_GET['id'] : null;

$data = ['nama_prestasi' => '', 'tingkat' => '', 'jenis' => ''];

if ($is_edit) {
    $stmt = $koneksi->prepare("SELECT * FROM jenis_prestasi WHERE id = ?");
    $stmt->bind_param("i", $id_jenis);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();
}
?>
<div class="container-fluid px-4">
    <h1 class="mt-4"><?php echo $is_edit ? 'Ubah' : 'Tambah'; ?> Jenis Prestasi</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=jenis_prestasi">Jenis Prestasi</a></li>
        <li class="breadcrumb-item active"><?php echo $is_edit ? 'Ubah' : 'Tambah'; ?></li>
    </ol>

    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-tag me-1"></i> Formulir Jenis Prestasi</div>
        <div class="card-body">
            <form action="index.php?action=<?php echo $is_edit ? 'proses_ubah_jenis_prestasi' : 'proses_tambah_jenis_prestasi'; ?>" method="POST">
                <?php if ($is_edit): ?><input type="hidden" name="id" value="<?php echo $id_jenis; ?>"><?php endif; ?>
                <div class="mb-3">
                    <label for="nama_prestasi" class="form-label">Nama Prestasi</label>
                    <input type="text" class="form-control" id="nama_prestasi" name="nama_prestasi" value="<?php echo htmlspecialchars($data['nama_prestasi']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="jenis" class="form-label">Jenis</label>
                    <select class="form-select" id="jenis" name="jenis" required>
                        <option value="">-- Pilih Jenis --</option>
                        <option value="Akademik" <?php echo ($data['jenis'] == 'Akademik') ? 'selected' : ''; ?>>Akademik</option>
                        <option value="Non-Akademik" <?php echo ($data['jenis'] == 'Non-Akademik') ? 'selected' : ''; ?>>Non-Akademik</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="tingkat" class="form-label">Tingkat</label>
                    <select class="form-select" id="tingkat" name="tingkat" required>
                        <option value="">-- Pilih Tingkat --</option>
                        <?php $tingkat_options = ['Sekolah', 'Kecamatan', 'Kabupaten', 'Provinsi', 'Nasional', 'Internasional']; ?>
                        <?php foreach($tingkat_options as $tingkat): ?>
                            <option value="<?php echo $tingkat; ?>" <?php echo ($data['tingkat'] == $tingkat) ? 'selected' : ''; ?>><?php echo $tingkat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="index.php?action=jenis_prestasi" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>