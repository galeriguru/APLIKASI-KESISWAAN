<?php
$is_edit = isset($_GET['id']);
$id_kelas = $is_edit ? $_GET['id'] : null;

$data = [
    'nama_kelas' => '',
    'wali_kelas' => ''
];

if ($is_edit) {
    $stmt = $koneksi->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->bind_param("i", $id_kelas);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    $stmt->close();

    if (!$data) {
        echo "Data kelas tidak ditemukan.";
        exit;
    }
}
?>
<div class="container-fluid px-4">
    <h1 class="mt-4"><?php echo $is_edit ? 'Ubah' : 'Tambah'; ?> Kelas</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=manajemen_kelas">Manajemen Kelas</a></li>
        <li class="breadcrumb-item active"><?php echo $is_edit ? 'Ubah' : 'Tambah'; ?></li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-<?php echo $is_edit ? 'edit' : 'plus'; ?> me-1"></i>
            Formulir Data Kelas
        </div>
        <div class="card-body">
            <form action="index.php?action=<?php echo $is_edit ? 'proses_ubah_kelas' : 'proses_tambah_kelas'; ?>" method="POST">
                <?php if ($is_edit): ?>
                    <input type="hidden" name="id" value="<?php echo $id_kelas; ?>">
                <?php endif; ?>
                
                <div class="mb-3">
                    <label for="nama_kelas" class="form-label">Nama Kelas</label>
                    <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" value="<?php echo htmlspecialchars($data['nama_kelas']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="wali_kelas" class="form-label">Wali Kelas</label>
                    <input type="text" class="form-control" id="wali_kelas" name="wali_kelas" value="<?php echo htmlspecialchars($data['wali_kelas']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="index.php?action=manajemen_kelas" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>