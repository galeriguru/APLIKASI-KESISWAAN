<?php
$query = "
    SELECT iz.*, s.nis, s.nama_lengkap AS nama_siswa, k.nama_kelas,
           u_pengaju.nama_lengkap AS nama_pengaju, u_penyetuju.nama_lengkap AS nama_penyetuju
    FROM izin_siswa iz
    JOIN siswa s ON iz.siswa_id = s.id
    JOIN kelas k ON s.kelas_id = k.id
    JOIN users u_pengaju ON iz.diajukan_oleh_user_id = u_pengaju.id
    LEFT JOIN users u_penyetuju ON iz.disetujui_oleh_user_id = u_penyetuju.id
    ORDER BY iz.created_at DESC
";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Izin Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Manajemen Izin Siswa</li>
    </ol>

    <?php if (isset($_GET['status'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php
                if ($_GET['status'] == 'sukses_ubah_status_izin') echo "Status izin berhasil diubah!";
                if ($_GET['status'] == 'sukses_hapus_izin') echo "Pengajuan izin berhasil dihapus!";
                // BARIS INI YANG DIUBAH
                if (strpos($_GET['status'], 'gagal') === 0) echo "Terjadi kesalahan. Aksi gagal diproses.";
            ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-list-alt me-1"></i>
            Daftar Pengajuan Izin Siswa
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Pengajuan</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Tanggal Izin</th>
                        <th>Jenis Izin</th>
                        <th>Keterangan</th>
                        <th>Bukti</th>
                        <th>Status</th>
                        <th>Pengaju</th>
                        <th>Penyetuju</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                        <td><?php echo htmlspecialchars($row['nis']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td>
                            <?php echo date('d-m-Y', strtotime($row['tanggal_izin_mulai'])); ?>
                            <?php echo ($row['tanggal_izin_selesai'] && $row['tanggal_izin_selesai'] != $row['tanggal_izin_mulai']) ? ' s/d ' . date('d-m-Y', strtotime($row['tanggal_izin_selesai'])) : ''; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['jenis_izin']); ?></td>
                        <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
                        <td>
                            <?php if (!empty($row['file_bukti'])): ?>
                                <a href="uploads/izin/<?php echo $row['file_bukti']; ?>" target="_blank" class="btn btn-info btn-sm">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge
                                <?php
                                    if($row['status'] == 'Diajukan') echo 'bg-secondary';
                                    elseif($row['status'] == 'Disetujui') echo 'bg-success';
                                    elseif($row['status'] == 'Ditolak') echo 'bg-danger';
                                    else echo 'bg-warning text-dark';
                                ?>
                            "><?php echo htmlspecialchars($row['status']); ?></span>
                        </td>
                        <td><?php echo htmlspecialchars($row['nama_pengaju']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_penyetuju'] ?? '-'); ?></td>
                        <td>
                            <?php if ($row['status'] == 'Diajukan'): ?>
                                <a href="index.php?action=proses_ubah_status_izin&id=<?php echo $row['id']; ?>&status=Disetujui" class="btn btn-success btn-sm" title="Setujui" onclick="return confirm('Setujui pengajuan izin ini?');"><i class="fas fa-check"></i></a>
                                <a href="index.php?action=proses_ubah_status_izin&id=<?php echo $row['id']; ?>&status=Ditolak" class="btn btn-warning btn-sm" title="Tolak" onclick="return confirm('Tolak pengajuan izin ini?');"><i class="fas fa-times"></i></a>
                            <?php endif; ?>
                            <a href="index.php?action=hapus_izin&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus pengajuan izin ini?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>