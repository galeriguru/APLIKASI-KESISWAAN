<?php
$query = "SELECT * FROM jenis_prestasi ORDER BY jenis, nama_prestasi";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Jenis Prestasi</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Jenis Prestasi</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-tags me-1"></i>
            Daftar Jenis Prestasi
            <a href="index.php?action=form_jenis_prestasi" class="btn btn-primary btn-sm float-end">
                <i class="fas fa-plus"></i> Tambah Jenis
            </a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Prestasi</th>
                        <th>Tingkat</th>
                        <th>Jenis</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nama_prestasi']); ?></td>
                        <td><?php echo htmlspecialchars($row['tingkat']); ?></td>
                        <td><span class="badge <?php echo ($row['jenis'] == 'Akademik') ? 'bg-primary' : 'bg-success'; ?>"><?php echo htmlspecialchars($row['jenis']); ?></span></td>
                        <td>
                            <a href="index.php?action=form_jenis_prestasi&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm" title="Ubah"><i class="fas fa-edit"></i></a>
                            <a href="index.php?action=hapus_jenis_prestasi&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>