<?php
// Data $report_data, $filter_bulan, $filter_tahun, $filter_kelas, $filter_siswa, $filter_jenis_pelanggaran
// serta nama-nama filter ($filter_kelas_nama, etc.) disediakan oleh index.php
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Laporan Pelanggaran Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Laporan Pelanggaran</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-filter me-1"></i>
            Filter Laporan Pelanggaran
        </div>
        <div class="card-body">
            <form action="index.php" method="GET" class="row g-3 align-items-end">
                <input type="hidden" name="action" value="laporan_pelanggaran">
                <div class="col-md-2">
                    <label for="bulan" class="form-label">Bulan</label>
                    <select class="form-select" id="bulan" name="bulan">
                        <option value="">Semua</option>
                        <?php for ($i = 1; $i <= 12; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($filter_bulan == $i) ? 'selected' : ''; ?>>
                                <?php echo get_bulan_indonesia($i); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label for="tahun" class="form-label">Tahun</label>
                    <select class="form-select" id="tahun" name="tahun">
                         <?php for ($i = date('Y'); $i >= date('Y') - 10; $i--): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($filter_tahun == $i) ? 'selected' : ''; ?>>
                                <?php echo $i; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="kelas_id" class="form-label">Kelas</label>
                    <select class="form-select" id="kelas_id" name="kelas_id">
                        <option value="">Semua Kelas</option>
                        <?php 
                         $kelas_result = mysqli_query($koneksi, "SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas");
                         while($kelas = mysqli_fetch_assoc($kelas_result)): ?>
                            <option value="<?php echo $kelas['id']; ?>" <?php echo ($filter_kelas == $kelas['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($kelas['nama_kelas']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="siswa_id" class="form-label">Nama Siswa</label>
                    <select class="form-select" id="siswa_id" name="siswa_id">
                        <option value="">Semua Siswa</option>
                        <?php 
                         $siswa_result = mysqli_query($koneksi, "SELECT id, nis, nama_lengkap FROM siswa ORDER BY nama_lengkap");
                         while($siswa = mysqli_fetch_assoc($siswa_result)): ?>
                            <option value="<?php echo $siswa['id']; ?>" <?php echo ($filter_siswa == $siswa['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($siswa['nis'] . ' - ' . $siswa['nama_lengkap']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="jenis_pelanggaran_id" class="form-label">Jenis Pelanggaran</label>
                    <select class="form-select" id="jenis_pelanggaran_id" name="jenis_pelanggaran_id">
                        <option value="">Semua Jenis</option>
                         <?php 
                         $jenis_pelanggaran_result = mysqli_query($koneksi, "SELECT id, nama_pelanggaran, poin FROM jenis_pelanggaran ORDER BY nama_pelanggaran");
                         while($jp = mysqli_fetch_assoc($jenis_pelanggaran_result)): ?>
                            <option value="<?php echo $jp['id']; ?>" <?php echo ($filter_jenis_pelanggaran == $jp['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($jp['nama_pelanggaran']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
                <div class="col-md-2">
                    <a href="index.php?action=laporan_pelanggaran" class="btn btn-secondary w-100">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Laporan Pelanggaran
            <div class="float-end">
                <a href="index.php?action=generate_laporan_pelanggaran_pdf&<?php echo http_build_query($_GET); ?>" target="_blank" class="btn btn-danger btn-sm">
                    <i class="fas fa-file-pdf"></i> Cetak PDF
                </a>
                <a href="index.php?action=generate_laporan_pelanggaran_excel&<?php echo http_build_query($_GET); ?>" class="btn btn-success btn-sm">
                    <i class="fas fa-file-excel"></i> Ekspor Excel
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Jenis Pelanggaran</th>
                        <th>Poin</th>
                        <th>Dicatat Oleh</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; if (!empty($report_data)): ?> <!-- Use $report_data from index.php -->
                        <?php foreach($report_data as $row): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                            <td><?php echo htmlspecialchars($row['nis']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                            <td><?php echo htmlspecialchars($row['nama_pelanggaran']); ?></td>
                            <td><span class="badge bg-danger"><?php echo htmlspecialchars($row['poin']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['nama_pencatat']); ?></td>
                            <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="text-center">Tidak ada data pelanggaran sesuai filter.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>