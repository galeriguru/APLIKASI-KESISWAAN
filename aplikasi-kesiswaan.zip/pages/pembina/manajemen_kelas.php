<?php
$query = "SELECT * FROM kelas ORDER BY nama_kelas";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Kelas</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Manajemen Kelas</li>
    </ol>

    <?php if (isset($_GET['status'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php
            $status = $_GET['status'];
            if ($status == 'sukses_tambah_kelas') echo "Data kelas berhasil ditambahkan!";
            if ($status == 'sukses_ubah_kelas') echo "Data kelas berhasil diubah!";
            if ($status == 'sukses_hapus_kelas') echo "Data kelas berhasil dihapus!";
            // Perbaikan: Menggunakan substr() untuk PHP 7
            if (substr($status, 0, 5) === 'gagal') {
                if ($status == 'gagal_hapus_kelas_siswa') echo "Gagal menghapus kelas. Masih ada siswa di kelas ini.";
                else echo "Terjadi kesalahan. Aksi gagal diproses.";
            }
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-school me-1"></i>
            Daftar Kelas
            <a href="index.php?action=tambah_kelas" class="btn btn-primary btn-sm float-end">
                <i class="fas fa-plus"></i> Tambah Kelas
            </a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kelas</th>
                        <th>Wali Kelas</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td><?php echo htmlspecialchars($row['wali_kelas']); ?></td>
                        <td>
                            <a href="index.php?action=ubah_kelas&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm" title="Ubah"><i class="fas fa-edit"></i></a>
                            <a href="index.php?action=hapus_kelas&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus kelas ini? Pastikan tidak ada siswa di kelas ini.');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>