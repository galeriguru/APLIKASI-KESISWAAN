<?php
$query = "SELECT id, username, nama_lengkap, role FROM users ORDER BY role, nama_lengkap";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Manajemen Pengguna</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Manajemen Pengguna</li>
    </ol>

    <?php if (isset($_GET['status'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php
            $status = $_GET['status'];
            if ($status == 'sukses_tambah_pengguna') echo "Pengguna berhasil ditambahkan!";
            if ($status == 'sukses_ubah_pengguna') echo "Data pengguna berhasil diubah!";
            if ($status == 'sukses_hapus_pengguna') echo "Pengguna berhasil dihapus!";
            if ($status == 'sukses_reset_password') echo "Password pengguna berhasil direset!";
            if (strpos($status, 'gagal') === 0) echo "Terjadi kesalahan. Aksi gagal diproses.";
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-user-cog me-1"></i>
            Daftar Akun Pengguna
            <a href="index.php?action=tambah_pengguna" class="btn btn-primary btn-sm float-end">
                <i class="fas fa-user-plus"></i> Tambah Pengguna
            </a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Nama Lengkap</th>
                        <th>Role</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                        <td><span class="badge
                            <?php
                                if($row['role'] == 'pembina') echo 'bg-primary';
                                elseif($row['role'] == 'siswa') echo 'bg-info';
                                elseif($row['role'] == 'orang_tua') echo 'bg-warning text-dark';
                                else echo 'bg-secondary';
                            ?>">
                            <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $row['role']))); ?>
                        </span></td>
                        <td>
                            <a href="index.php?action=ubah_pengguna&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm" title="Ubah Data"><i class="fas fa-edit"></i></a>
                            <a href="index.php?action=reset_password_pengguna&id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm text-white" title="Reset Password" onclick="return confirm('Apakah Anda yakin ingin mereset password pengguna ini? Password akan direset menjadi username pengguna.');"><i class="fas fa-key"></i></a>
                            <?php if ($row['id'] != $_SESSION['user_id']): ?>
                            <a href="index.php?action=hapus_pengguna&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus Pengguna" onclick="return confirm('PERINGATAN: Menghapus akun ini mungkin akan mempengaruhi data yang terkait (siswa, orang tua). Apakah Anda yakin?');"><i class="fas fa-trash"></i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>