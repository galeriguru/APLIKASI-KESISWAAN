<?php
$query = "
    SELECT ps.*, s.nama_lengkap AS nama_siswa, s.nis, k.nama_kelas, 
           jp.nama_pelanggaran, jp.poin, u.nama_lengkap AS nama_pencatat
    FROM pelanggaran_siswa ps
    JOIN siswa s ON ps.siswa_id = s.id
    JOIN kelas k ON s.kelas_id = k.id
    JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id
    JOIN users u ON ps.dicatat_oleh_user_id = u.id
    ORDER BY ps.tanggal DESC, s.nama_lengkap ASC
";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Riwayat Pelanggaran Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Riwayat Pelanggaran</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-history me-1"></i>
            Semua Catatan Pelanggaran
            <a href="index.php?action=tambah_pelanggaran_siswa" class="btn btn-danger btn-sm float-end">
                <i class="fas fa-plus"></i> Catat Pelanggaran
            </a>
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Pelanggaran</th>
                        <th>Poin</th>
                        <th>Dicatat Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                        <td><?php echo htmlspecialchars($row['nis']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_pelanggaran']); ?></td>
                        <td><span class="badge bg-danger"><?php echo htmlspecialchars($row['poin']); ?></span></td>
                        <td><?php echo htmlspecialchars($row['nama_pencatat']); ?></td>
                        <td>
                            <a href="index.php?action=hapus_pelanggaran_siswa&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus catatan pelanggaran ini? Poin siswa akan dikembalikan.');"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>