<?php
// Query untuk mendapatkan total poin pelanggaran per siswa
$query_poin = "
    SELECT 
        s.id AS siswa_id,
        s.nis,
        s.nama_lengkap AS nama_siswa,
        k.nama_kelas,
        u_ortu.nama_lengkap AS nama_ortu,
        SUM(jp.poin) AS total_poin_pelanggaran
    FROM siswa s
    JOIN kelas k ON s.kelas_id = k.id
    LEFT JOIN users u_ortu ON s.ortu_user_id = u_ortu.id
    LEFT JOIN pelanggaran_siswa ps ON s.id = ps.siswa_id
    LEFT JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id
    GROUP BY s.id, s.nis, s.nama_lengkap, k.nama_kelas, u_ortu.nama_lengkap
    HAVING total_poin_pelanggaran >= " . AMBANG_BATAS_POIN_PANGGILAN . "
    ORDER BY total_poin_pelanggaran DESC
";
$result_poin = mysqli_query($koneksi, $query_poin);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Surat Panggilan Orang Tua</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Surat Panggilan Ortu</li>
    </ol>

    <div class="alert alert-info" role="alert">
        Daftar siswa di bawah ini memiliki total poin pelanggaran di atas atau sama dengan ambang batas (<?php echo AMBANG_BATAS_POIN_PANGGILAN; ?> poin) sehingga membutuhkan surat panggilan orang tua.
    </div>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-envelope-open-text me-1"></i>
            Daftar Siswa untuk Panggilan Orang Tua
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Nama Orang Tua</th>
                        <th>Total Poin Pelanggaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while($row = mysqli_fetch_assoc($result_poin)): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nis']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                        <td><?php echo htmlspecialchars($row['nama_ortu'] ?? 'Tidak Terdaftar'); ?></td>
                        <td><span class="badge bg-danger"><?php echo htmlspecialchars($row['total_poin_pelanggaran']); ?></span></td>
                        <td>
                            <a href="index.php?action=generate_surat_panggilan&siswa_id=<?php echo $row['siswa_id']; ?>" target="_blank" class="btn btn-success btn-sm" title="Buat & Unduh Surat">
                                <i class="fas fa-file-pdf"></i> Generate Surat PDF
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>