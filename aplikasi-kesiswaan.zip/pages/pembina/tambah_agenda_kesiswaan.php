<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Agenda Kesiswaan</title>
    <!-- Pastikan Anda memuat Bootstrap 5 CSS dan Font Awesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>

    <div class="container-fluid px-4 py-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h3 mb-0 text-gray-800">Tambah Agenda Kesiswaan</h1>
            <ol class="breadcrumb d-none d-md-flex bg-transparent p-0 m-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="index.php?action=agenda_kesiswaan">Agenda Kesiswaan</a></li>
                <li class="breadcrumb-item active">Tambah Agenda</li>
            </ol>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-plus-circle me-2"></i>Formulir Tambah Agenda</h6>
            </div>
            <div class="card-body p-4">
                <form action="index.php?action=proses_tambah_agenda_kesiswaan" method="POST">
                    
                    <div class="mb-3">
                        <label for="judul_kegiatan" class="form-label">Judul Kegiatan</label>
                        <input type="text" class="form-control" id="judul_kegiatan" name="judul_kegiatan" placeholder="Contoh: Rapat OSIS Bulanan" required>
                    </div>
                    
                    <div class="mb-4">
                        <label for="deskripsi" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" placeholder="Jelaskan detail kegiatan di sini..."></textarea>
                    </div>

                    <div class="row gx-3 mb-3">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <label for="tanggal_mulai" class="form-label">Tanggal dan Waktu Mulai</label>
                            <input type="datetime-local" class="form-control" id="tanggal_mulai" name="tanggal_mulai" required>
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_selesai" class="form-label">
                                Tanggal dan Waktu Selesai 
                                <small class="text-muted">(Opsional)</small>
                            </label>
                            <input type="datetime-local" class="form-control" id="tanggal_selesai" name="tanggal_selesai">
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="index.php?action=agenda_kesiswaan" class="btn btn-outline-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>
                            Simpan Agenda
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <!-- Pastikan Anda memuat Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>