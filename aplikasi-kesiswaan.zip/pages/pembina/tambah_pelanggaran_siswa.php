<?php
// Pastikan variabel $koneksi sudah ada dan terhubung ke database.
// Contoh: $koneksi = mysqli_connect("localhost", "username", "password", "database");

$siswa_result = mysqli_query($koneksi, "SELECT id, nis, nama_lengkap FROM siswa ORDER BY nama_lengkap");
$jenis_pelanggaran_result = mysqli_query($koneksi, "SELECT id, nama_pelanggaran, poin FROM jenis_pelanggaran ORDER BY poin DESC, nama_pelanggaran ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catat Pelanggaran Siswa</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.bootstrap5.css" rel="stylesheet">
    
    <style>
        body { background-color: #f8f9fa; }
        .ts-control { padding: 0.5rem 0.75rem; }
    </style>
</head>
<body>

    <div class="container-fluid px-4 py-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h3 mb-0 text-gray-800">Catat Pelanggaran Siswa</h1>
            <ol class="breadcrumb d-none d-md-flex bg-transparent p-0 m-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="index.php?action=pelanggaran_siswa">Riwayat Pelanggaran</a></li>
                <li class="breadcrumb-item active">Catat Pelanggaran</li>
            </ol>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-gavel me-2"></i>Formulir Pencatatan Pelanggaran</h6>
            </div>
            <div class="card-body p-4">
                <form action="index.php?action=proses_tambah_pelanggaran_siswa" method="POST">
                    
                    <div class="mb-3">
                        <label for="select-siswa" class="form-label">Pilih Siswa</label>
                        <select id="select-siswa" name="siswa_id" required>
                            <option value="">Ketik untuk mencari siswa...</option>
                            <?php while($siswa = mysqli_fetch_assoc($siswa_result)): ?>
                            <option value="<?php echo $siswa['id']; ?>"><?php echo htmlspecialchars($siswa['nis'] . ' - ' . $siswa['nama_lengkap']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="row gx-3 mb-3">
                        <div class="col-md-8 mb-3 mb-md-0">
                            <label for="select-pelanggaran" class="form-label">Jenis Pelanggaran</label>
                            <select id="select-pelanggaran" name="jenis_pelanggaran_id" required>
                                <option value="">Ketik untuk mencari pelanggaran...</option>
                                <?php while($jp = mysqli_fetch_assoc($jenis_pelanggaran_result)): ?>
                                <option value="<?php echo $jp['id']; ?>"><?php echo htmlspecialchars($jp['nama_pelanggaran'] . ' (' . $jp['poin'] . ' Poin)'); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="tanggal" class="form-label">Tanggal Pelanggaran</label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="keterangan" class="form-label">
                            Keterangan Tambahan <small class="text-muted">(Opsional)</small>
                        </label>
                        <textarea class="form-control" id="keterangan" name="keterangan" rows="3" placeholder="Catatan spesifik tentang lokasi, waktu, atau saksi..."></textarea>
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="index.php?action=pelanggaran_siswa" class="btn btn-outline-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>
                            Simpan Catatan
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            new TomSelect('#select-siswa', {
                create: false,
                sortField: {
                    field: "text",
                    direction: "asc"
                }
            });

            new TomSelect('#select-pelanggaran', {
                create: false,
                sortField: {
                    field: "text",
                    direction: "asc"
                }
            });
        });
    </script>
</body>
</html>