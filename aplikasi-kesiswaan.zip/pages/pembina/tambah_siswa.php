<?php
// Asumsikan $koneksi sudah ada dan terhubung ke database
$kelas_result = mysqli_query($koneksi, "SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Siswa</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; }
    </style>
</head>
<body>

    <div class="container-fluid px-4 py-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h3 mb-0 text-gray-800">Tambah Data Siswa</h1>
            <ol class="breadcrumb d-none d-md-flex bg-transparent p-0 m-0">
                <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="index.php?action=data_siswa">Data Siswa</a></li>
                <li class="breadcrumb-item active">Tambah Siswa</li>
            </ol>
        </div>

        <div class="card shadow-sm mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-user-plus me-2"></i>Formulir Tambah Siswa</h6>
            </div>
            <div class="card-body p-4">
                <form action="index.php?action=proses_tambah_siswa" method="POST">
                    
                    <h6 class="text-primary">Informasi Siswa</h6>
                    <hr class="mt-2 mb-4">
                    
                    <div class="row gx-3 mb-3">
                        <div class="col-md-6">
                            <label for="nis" class="form-label">NIS (Nomor Induk Siswa)</label>
                            <input type="text" class="form-control" id="nis" name="nis" placeholder="Masukkan NIS unik" required>
                        </div>
                        <div class="col-md-6">
                            <label for="nama_lengkap" class="form-label">Nama Lengkap Siswa</label>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Masukkan nama sesuai akta" required>
                        </div>
                    </div>

                    <div class="row gx-3 mb-3">
                        <div class="col-md-6">
                            <label for="kelas_id" class="form-label">Kelas</label>
                            <select class="form-select" id="kelas_id" name="kelas_id" required>
                                <option value="" selected disabled>-- Pilih Kelas --</option>
                                <?php while($kelas = mysqli_fetch_assoc($kelas_result)): ?>
                                <option value="<?php echo $kelas['id']; ?>"><?php echo htmlspecialchars($kelas['nama_kelas']); ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="no_telepon" class="form-label">Nomor Telepon (Siswa/Orang Tua)</label>
                            <input type="tel" class="form-control" id="no_telepon" name="no_telepon" placeholder="Contoh: 08123456789">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat lengkap siswa..."></textarea>
                    </div>

                    <h6 class="text-primary mt-4">Informasi Orang Tua / Wali</h6>
                    <hr class="mt-2 mb-4">
                    
                    <div class="mb-3">
                        <label for="nama_ortu" class="form-label">Nama Lengkap Orang Tua/Wali</label>
                        <input type="text" class="form-control" id="nama_ortu" name="nama_ortu" placeholder="Masukkan nama orang tua/wali" required>
                    </div>

                    <div class="alert alert-info small" role="alert">
                        <i class="fas fa-info-circle me-2"></i>
                        NIS akan digunakan sebagai <strong>Username & Password default</strong> untuk login siswa. Username orang tua akan dibuat otomatis (contoh: <strong>ortu_NIS</strong>).
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <a href="index.php?action=data_siswa" class="btn btn-outline-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>
                            Simpan Data
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>