<?php
$id_agenda = $_GET['id'] ?? 0;
if ($id_agenda == 0) {
    echo "ID Agenda tidak valid.";
    exit;
}

$stmt = $koneksi->prepare("SELECT * FROM agenda_kesiswaan WHERE id = ?");
$stmt->bind_param("i", $id_agenda);
$stmt->execute();
$result = $stmt->get_result();
$data_agenda = $result->fetch_assoc();
$stmt->close();

if (!$data_agenda) {
    echo "Data agenda tidak ditemukan.";
    exit;
}
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Ubah Agenda Kesiswaan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=agenda_kesiswaan">Agenda Kesiswaan</a></li>
        <li class="breadcrumb-item active">Ubah Agenda</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Formulir Ubah Agenda</div>
        <div class="card-body">
            <form action="index.php?action=proses_ubah_agenda_kesiswaan" method="POST">
                <input type="hidden" name="id" value="<?php echo $id_agenda; ?>">
                
                <div class="mb-3">
                    <label for="judul_kegiatan" class="form-label">Judul Kegiatan</label>
                    <input type="text" class="form-control" id="judul_kegiatan" name="judul_kegiatan" value="<?php echo htmlspecialchars($data_agenda['judul_kegiatan']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="deskripsi" class="form-label">Deskripsi</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4"><?php echo htmlspecialchars($data_agenda['deskripsi']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="tanggal_mulai" class="form-label">Tanggal dan Waktu Mulai</label>
                    <input type="datetime-local" class="form-control" id="tanggal_mulai" name="tanggal_mulai" value="<?php echo date('Y-m-d\TH:i', strtotime($data_agenda['tanggal_mulai'])); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="tanggal_selesai" class="form-label">Tanggal dan Waktu Selesai (Opsional)</label>
                    <input type="datetime-local" class="form-control" id="tanggal_selesai" name="tanggal_selesai" value="<?php echo $data_agenda['tanggal_selesai'] ? date('Y-m-d\TH:i', strtotime($data_agenda['tanggal_selesai'])) : ''; ?>">
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="index.php?action=agenda_kesiswaan" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>