<?php
$id_kelas = $_GET['id'] ?? 0;
if ($id_kelas == 0) {
    echo "ID Kelas tidak valid.";
    exit;
}

$stmt = $koneksi->prepare("SELECT * FROM kelas WHERE id = ?");
$stmt->bind_param("i", $id_kelas);
$stmt->execute();
$result = $stmt->get_result();
$data_kelas = $result->fetch_assoc();
$stmt->close();

if (!$data_kelas) {
    echo "Data kelas tidak ditemukan.";
    exit;
}
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Ubah Data Kelas</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=manajemen_kelas">Manajemen Kelas</a></li>
        <li class="breadcrumb-item active">Ubah Kelas</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Formulir Ubah Kelas
        </div>
        <div class="card-body">
            <form action="index.php?action=proses_ubah_kelas" method="POST">
                <input type="hidden" name="id" value="<?php echo $id_kelas; ?>">
                
                <div class="mb-3">
                    <label for="nama_kelas" class="form-label">Nama Kelas</label>
                    <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" value="<?php echo htmlspecialchars($data_kelas['nama_kelas']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="wali_kelas" class="form-label">Wali Kelas</label>
                    <input type="text" class="form-control" id="wali_kelas" name="wali_kelas" value="<?php echo htmlspecialchars($data_kelas['wali_kelas']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="index.php?action=manajemen_kelas" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>