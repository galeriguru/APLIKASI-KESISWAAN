<?php
$id_user = $_GET['id'] ?? 0;
if ($id_user == 0) {
    echo "ID Pengguna tidak valid.";
    exit;
}

$stmt = $koneksi->prepare("SELECT id, username, nama_lengkap, role FROM users WHERE id = ?");
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();
$data_user = $result->fetch_assoc();
$stmt->close();

if (!$data_user) {
    echo "Data pengguna tidak ditemukan.";
    exit;
}

// Cek apakah pengguna yang sedang login mencoba mengedit akunnya sendiri
$is_self_edit = ($data_user['id'] == $_SESSION['user_id']);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Ubah Data Pengguna</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=manajemen_pengguna">Manajemen Pengguna</a></li>
        <li class="breadcrumb-item active">Ubah Pengguna</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header"><i class="fas fa-edit me-1"></i> Formulir Ubah Pengguna</div>
        <div class="card-body">
            <form action="index.php?action=proses_ubah_pengguna" method="POST">
                <input type="hidden" name="id" value="<?php echo $id_user; ?>">
                <input type="hidden" name="old_role" value="<?php echo htmlspecialchars($data_user['role']); ?>">
                
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($data_user['username']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password (Kosongkan jika tidak ingin diubah)</label>
                    <input type="password" class="form-control" id="password" name="password">
                    <div class="form-text">Isi kolom ini jika Anda ingin mengubah password pengguna.</div>
                </div>
                <div class="mb-3">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($data_user['nama_lengkap']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-select" id="role" name="role" required <?php echo $is_self_edit ? 'disabled' : ''; ?>>
                        <option value="pembina" <?php echo ($data_user['role'] == 'pembina') ? 'selected' : ''; ?>>Pembina Kesiswaan</option>
                        <option value="siswa" <?php echo ($data_user['role'] == 'siswa') ? 'selected' : ''; ?>>Siswa</option>
                        <option value="orang_tua" <?php echo ($data_user['role'] == 'orang_tua') ? 'selected' : ''; ?>>Orang Tua</option>
                    </select>
                    <?php if ($is_self_edit): ?>
                        <input type="hidden" name="role" value="<?php echo htmlspecialchars($data_user['role']); ?>">
                        <div class="form-text text-danger">Anda tidak bisa mengubah role akun Anda sendiri.</div>
                    <?php endif; ?>
                    <?php if ($data_user['role'] == 'siswa' || $data_user['role'] == 'orang_tua'): ?>
                        <div class="form-text text-danger">Untuk akun Siswa dan Orang Tua, perubahan nama lengkap dan relasi mungkin perlu disesuaikan juga di menu "Manajemen Data Siswa".</div>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="index.php?action=manajemen_pengguna" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>