<?php
$id_siswa = $_GET['id'] ?? 0;
if ($id_siswa == 0) {
    // Sebaiknya redirect atau tampilkan pesan error yang lebih baik
    echo "ID Siswa tidak valid.";
    exit;
}

// Ambil data siswa yang akan diubah, termasuk nama orang tuanya dari tabel users
$stmt = $koneksi->prepare("
    SELECT s.*, u_ortu.nama_lengkap as nama_ortu
    FROM siswa s
    LEFT JOIN users u_ortu ON s.ortu_user_id = u_ortu.id
    WHERE s.id = ?
");
$stmt->bind_param("i", $id_siswa);
$stmt->execute();
$result = $stmt->get_result();
$siswa = $result->fetch_assoc();
$stmt->close();

if (!$siswa) {
    echo "Data siswa tidak ditemukan.";
    exit;
}

// Ambil semua data kelas untuk ditampilkan di dropdown
$kelas_result = mysqli_query($koneksi, "SELECT * FROM kelas ORDER BY nama_kelas");
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Ubah Data Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="index.php?action=data_siswa">Data Siswa</a></li>
        <li class="breadcrumb-item active">Ubah Siswa</li>
    </ol>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-edit me-1"></i>
            Formulir Ubah Siswa
        </div>
        <div class="card-body">
            <form action="index.php?action=proses_ubah_siswa" method="POST">
                <!-- Hidden fields untuk menyimpan ID penting -->
                <input type="hidden" name="id_siswa" value="<?php echo $siswa['id']; ?>">
                <input type="hidden" name="user_id_siswa" value="<?php echo $siswa['user_id']; ?>">
                <input type="hidden" name="ortu_user_id" value="<?php echo $siswa['ortu_user_id']; ?>">

                <div class="mb-3">
                    <label for="nis" class="form-label">NIS (Nomor Induk Siswa)</label>
                    <input type="text" class="form-control" id="nis" name="nis" value="<?php echo htmlspecialchars($siswa['nis']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap Siswa</label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?php echo htmlspecialchars($siswa['nama_lengkap']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="kelas_id" class="form-label">Kelas</label>
                    <select class="form-select" id="kelas_id" name="kelas_id" required>
                        <option value="">-- Pilih Kelas --</option>
                        <?php while($kelas = mysqli_fetch_assoc($kelas_result)): ?>
                        <option value="<?php echo $kelas['id']; ?>" <?php echo ($kelas['id'] == $siswa['kelas_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kelas['nama_kelas']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo htmlspecialchars($siswa['alamat']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="no_telepon" class="form-label">Nomor Telepon (Siswa/Orang Tua)</label>
                    <input type="tel" class="form-control" id="no_telepon" name="no_telepon" value="<?php echo htmlspecialchars($siswa['no_telepon']); ?>">
                </div>
                <hr>
                <div class="mb-3">
                    <label for="nama_ortu" class="form-label">Nama Lengkap Orang Tua/Wali</label>
                    <input type="text" class="form-control" id="nama_ortu" name="nama_ortu" value="<?php echo htmlspecialchars($siswa['nama_ortu']); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="index.php?action=data_siswa" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>