<?php
// Ambil semua data agenda, diurutkan berdasarkan tanggal mulai
$query = "SELECT * FROM agenda_kesiswaan ORDER BY tanggal_mulai DESC";
$result = mysqli_query($koneksi, $query);
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Agenda Kegiatan Kesiswaan</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Agenda Kegiatan</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-calendar-days me-1"></i>
            Daftar Kegiatan Mendatang
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>Judul Kegiatan</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo date('d-m-Y H:i', strtotime($row['tanggal_mulai'])); ?></td>
                        <td><?php echo $row['tanggal_selesai'] ? date('d-m-Y H:i', strtotime($row['tanggal_selesai'])) : '-'; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['judul_kegiatan']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>