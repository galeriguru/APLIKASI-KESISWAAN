<?php
// Ambil data siswa yang sedang login
$user_id_siswa = $_SESSION['user_id'];
$stmt_siswa = $koneksi->prepare("SELECT id FROM siswa WHERE user_id = ?");
$stmt_siswa->bind_param("i", $user_id_siswa);
$stmt_siswa->execute();
$data_siswa_login = $stmt_siswa->get_result()->fetch_assoc();
$stmt_siswa->close();

if (!$data_siswa_login) {
    echo '<div class="alert alert-danger">Data siswa tidak ditemukan untuk akun ini. Silakan hubungi administrator.</div>';
    exit;
}

$siswa_id_login = $data_siswa_login['id'];

$query = "
    SELECT ds.*, u_uploader.nama_lengkap AS nama_uploader
    FROM dokumen_siswa ds
    JOIN users u_uploader ON ds.uploaded_by_user_id = u_uploader.id
    WHERE ds.siswa_id = ?
    ORDER BY ds.created_at DESC
";
$stmt_dokumen = $koneksi->prepare($query);
$stmt_dokumen->bind_param("i", $siswa_id_login);
$stmt_dokumen->execute();
$result = $stmt_dokumen->get_result();
$stmt_dokumen->close();
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dokumen Pengajuan Saya</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active">Dokumen Saya</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-list me-1"></i>
            Daftar Dokumen yang Saya Upload
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Tanggal Upload</th>
                        <th>Judul Dokumen</th>
                        <th>Jenis Dokumen</th>
                        <th>Deskripsi</th>
                        <th>File</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo date('d-m-Y H:i', strtotime($row['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($row['judul_dokumen']); ?></td>
                            <td><?php echo htmlspecialchars($row['jenis_dokumen'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['deskripsi']); ?></td>
                            <td>
                                <?php if (!empty($row['file_path'])): ?>
                                    <a href="uploads/dokumen/<?php echo $row['file_path']; ?>" target="_blank" class="btn btn-primary btn-sm">Lihat</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="index.php?action=hapus_dokumen_saya&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus dokumen ini?');"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center">Anda belum mengupload dokumen apapun.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>