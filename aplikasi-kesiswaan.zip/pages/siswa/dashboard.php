<?php
// pages/siswa/dashboard.php

// Ambil user_id dari session
$user_id_siswa = $_SESSION['user_id'];

// Query untuk mengambil data lengkap siswa berdasarkan user_id
$stmt = $koneksi->prepare("SELECT s.*, k.nama_kelas, k.wali_kelas FROM siswa s JOIN kelas k ON s.kelas_id = k.id WHERE s.user_id = ?");
$stmt->bind_param("i", $user_id_siswa);
$stmt->execute();
$result = $stmt->get_result();
$data_siswa = $result->fetch_assoc();
$stmt->close();

// Query untuk menghitung total prestasi dan pelanggaran
$total_prestasi = $koneksi->query("SELECT COUNT(*) as total FROM prestasi_siswa WHERE siswa_id = {$data_siswa['id']}")->fetch_assoc()['total'];
$total_poin_pelanggaran = $koneksi->query("SELECT SUM(jp.poin) as total FROM pelanggaran_siswa ps JOIN jenis_pelanggaran jp ON ps.jenis_pelanggaran_id = jp.id WHERE ps.siswa_id = {$data_siswa['id']}")->fetch_assoc()['total'] ?? 0;

?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard Siswa</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Selamat datang, <?php echo htmlspecialchars($data_siswa['nama_lengkap']); ?>!</li>
    </ol>

    <!-- Card Statistik -->
    <div class="row">
        <div class="col-xl-6 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <h4>Total Prestasi</h4>
                    <p class="h1"><?php echo $total_prestasi; ?></p>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">Lihat Detail Prestasi</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6">
            <div class="card bg-danger text-white mb-4">
                <div class="card-body">
                    <h4>Total Poin Pelanggaran</h4>
                    <p class="h1"><?php echo $total_poin_pelanggaran; ?></p>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#">Lihat Riwayat Pelanggaran</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Informasi Detail Siswa -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-user me-1"></i>
            Informasi Pribadi
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th width="200px">NIS</th>
                    <td><?php echo htmlspecialchars($data_siswa['nis']); ?></td>
                </tr>
                <tr>
                    <th>Nama Lengkap</th>
                    <td><?php echo htmlspecialchars($data_siswa['nama_lengkap']); ?></td>
                </tr>
                <tr>
                    <th>Kelas</th>
                    <td><?php echo htmlspecialchars($data_siswa['nama_kelas']); ?></td>
                </tr>
                <tr>
                    <th>Wali Kelas</th>
                    <td><?php echo htmlspecialchars($data_siswa['wali_kelas']); ?></td>
                </tr>
                <tr>
                    <th>Alamat</th>
                    <td><?php echo htmlspecialchars($data_siswa['alamat']); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>