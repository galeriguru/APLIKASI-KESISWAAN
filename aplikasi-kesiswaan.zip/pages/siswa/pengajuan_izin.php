<?php
// Asumsikan $koneksi dan session sudah berjalan
$user_id_siswa = $_SESSION['user_id'];
$stmt_siswa = $koneksi->prepare("SELECT id, nama_lengkap FROM siswa WHERE user_id = ?");
$stmt_siswa->bind_param("i", $user_id_siswa);
$stmt_siswa->execute();
$data_siswa_login = $stmt_siswa->get_result()->fetch_assoc();
$stmt_siswa->close();

if (!$data_siswa_login) {
    echo '<div class="alert alert-danger m-4">Data siswa tidak ditemukan untuk akun ini. Silakan hubungi administrator.</div>';
    exit;
}

$alert_message = '';
$alert_type = '';
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'sukses_pengajuan_izin') {
        $alert_message = 'Pengajuan izin berhasil dikirim! Menunggu persetujuan dari wali kelas.';
        $alert_type = 'success';
    } elseif (strpos($_GET['status'], 'gagal') === 0) {
        $alert_message = 'Pengajuan gagal. Silakan periksa kembali isian Anda atau hubungi administrator.';
        $alert_type = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Izin Tidak Hadir</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; }
    </style>
</head>
<body>

<div class="container-fluid px-4 py-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0 text-gray-800">Pengajuan Izin Tidak Hadir</h1>
        <ol class="breadcrumb d-none d-md-flex bg-transparent p-0 m-0">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Pengajuan Izin</li>
        </ol>
    </div>

    <?php if ($alert_message): ?>
        <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($alert_message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-file-alt me-2"></i>Formulir Pengajuan Izin</h6>
        </div>
        <div class="card-body p-4">
            <form action="index.php?action=proses_pengajuan_izin" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="siswa_id" value="<?php echo $data_siswa_login['id']; ?>">
                
                <div class="mb-3">
                    <label for="jenis_izin" class="form-label">Jenis Izin</label>
                    <select class="form-select" id="jenis_izin" name="jenis_izin" required>
                        <option value="" selected disabled>-- Pilih Jenis Izin --</option>
                        <option value="Sakit">Sakit</option>
                        <option value="Izin Pribadi">Izin Pribadi</option>
                        <option value="Kegiatan Sekolah">Dispensasi (Kegiatan Sekolah)</option>
                        <option value="Lain-lain">Lain-lain</option>
                    </select>
                </div>
                
                <div class="row gx-3 mb-3">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label for="tanggal_izin_mulai" class="form-label">Tanggal Mulai Izin</label>
                        <input type="date" class="form-control" id="tanggal_izin_mulai" name="tanggal_izin_mulai" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="tanggal_izin_selesai" class="form-label">
                            Tanggal Selesai Izin <small class="text-muted">(Jika > 1 hari)</small>
                        </label>
                        <input type="date" class="form-control" id="tanggal_izin_selesai" name="tanggal_izin_selesai">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="keterangan" class="form-label">Keterangan / Alasan</label>
                    <textarea class="form-control" id="keterangan" name="keterangan" rows="3" placeholder="Jelaskan alasan izin Anda secara singkat dan jelas..." required></textarea>
                </div>
                
                <div class="mb-3">
                    <label for="file_bukti" class="form-label">
                        Upload Bukti <small class="text-muted">(Surat Dokter, dll.)</small>
                    </label>
                    <input class="form-control" type="file" id="file_bukti" name="file_bukti" accept="image/*,application/pdf">
                    <div class="form-text">Opsional. Format: JPG, PNG, PDF (Maks. 2MB).</div>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                    <a href="index.php" class="btn btn-outline-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-1"></i>
                        Ajukan Izin
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>