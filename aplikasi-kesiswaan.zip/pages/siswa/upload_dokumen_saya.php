<?php
// Asumsikan $koneksi dan session sudah berjalan
$user_id_siswa = $_SESSION['user_id'];
$stmt_siswa = $koneksi->prepare("SELECT id, nama_lengkap FROM siswa WHERE user_id = ?");
$stmt_siswa->bind_param("i", $user_id_siswa);
$stmt_siswa->execute();
$data_siswa_login = $stmt_siswa->get_result()->fetch_assoc();
$stmt_siswa->close();

if (!$data_siswa_login) {
    echo '<div class="alert alert-danger m-4">Data siswa tidak ditemukan untuk akun ini. Silakan hubungi administrator.</div>';
    exit;
}

$alert_message = '';
$alert_type = '';
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'sukses_upload_dokumen') {
        $alert_message = 'Dokumen berhasil diupload! Menunggu proses lebih lanjut.';
        $alert_type = 'success';
    } elseif (str_starts_with($_GET['status'], 'gagal')) {
        $alert_message = 'Terjadi kesalahan saat mengupload dokumen. Pastikan file tidak melebihi batas ukuran.';
        $alert_type = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Dokumen</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; }
    </style>
</head>
<body>

<div class="container-fluid px-4 py-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3 mb-0 text-gray-800">Upload Dokumen</h1>
        <ol class="breadcrumb d-none d-md-flex bg-transparent p-0 m-0">
            <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
            <li class="breadcrumb-item active">Upload Dokumen</li>
        </ol>
    </div>
    
    <?php if ($alert_message): ?>
        <div class="alert alert-<?php echo $alert_type; ?> alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($alert_message); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-upload me-2"></i>Formulir Upload Dokumen</h6>
        </div>
        <div class="card-body p-4">
            <form action="index.php?action=proses_upload_dokumen" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="siswa_id" value="<?php echo $data_siswa_login['id']; ?>">
                
                <div class="row gx-3 mb-3">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <label for="judul_dokumen" class="form-label">Judul Dokumen</label>
                        <input type="text" class="form-control" id="judul_dokumen" name="judul_dokumen" placeholder="Contoh: Surat Pernyataan Orang Tua" required>
                    </div>
                    <div class="col-md-6">
                        <label for="jenis_dokumen" class="form-label">
                            Jenis Dokumen <small class="text-muted">(Opsional)</small>
                        </label>
                        <input type="text" class="form-control" id="jenis_dokumen" name="jenis_dokumen" placeholder="Contoh: Formulir Beasiswa">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="deskripsi" class="form-label">Deskripsi / Keterangan</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" placeholder="Tambahkan keterangan singkat mengenai tujuan atau isi dokumen..."></textarea>
                </div>

                <div class="mb-3">
                    <label for="file_dokumen" class="form-label">Pilih File Dokumen</label>
                    <input class="form-control" type="file" id="file_dokumen" name="file_dokumen" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
                    <div class="form-text">Format: PDF, DOCX, JPG, PNG (Maks. 5MB).</div>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                    <a href="index.php" class="btn btn-outline-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload me-1"></i>
                        Upload Dokumen
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>