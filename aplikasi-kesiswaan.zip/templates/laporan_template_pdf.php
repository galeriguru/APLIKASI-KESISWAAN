<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan <?php echo $report_title; ?></title>
    <style>
        body { font-family: 'Times New Roman', Times, serif; font-size: 10pt; line-height: 1.5; margin: 40px; }
        .header { text-align: center; margin-bottom: 30px; }
        .header img { width: 80px; float: left; margin-right: 15px; }
        .header h2, .header h3, .header p { margin: 0; padding: 0; }
        .header p { font-size: 9pt; }
        h1 { text-align: center; margin-top: 30px; margin-bottom: 20px; font-size: 16pt; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .filters { margin-bottom: 20px; font-size: 10pt; }
        .filters span { font-weight: bold; }
        .footer { text-align: right; margin-top: 50px; font-size: 9pt; }
        .ttd { text-align: center; margin-top: 50px; }
        .ttd p { margin: 0; padding: 0; }
        .nama-pejabat { font-weight: bold; text-decoration: underline; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo BASE_URL; ?>/assets/logo_sekolah.png" alt="Logo Sekolah" style="width: 80px;">
        <h3>PEMERINTAH KABUPATEN/KOTA [...]</h3>
        <h3>DINAS PENDIDIKAN</h3>
        <h2>SMA/SMK NEGERI [Nama Sekolah Anda]</h2>
        <p>Alamat: Jl. Contoh No. 123, Kota Contoh, Provinsi Contoh | Telepon: (021) 12345678</p>
        <hr style="border: 1px solid black;">
    </div>

    <h1>LAPORAN <?php echo strtoupper($report_title); ?></h1>

    <div class="filters">
        <p>
            Filter: 
            <?php echo isset($filter_bulan_nama) && !empty($filter_bulan_nama) ? "Bulan: <span>" . $filter_bulan_nama . "</span>, " : ""; ?>
            Tahun: <span><?php echo $filter_tahun; ?></span>,
            Kelas: <span><?php echo $filter_kelas_nama ?? 'Semua'; ?></span>,
            Siswa: <span><?php echo $filter_siswa_nama ?? 'Semua'; ?></span>,
            Jenis: <span><?php echo $filter_jenis_nama ?? 'Semua'; ?></span>
        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>NIS</th>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Nama Prestasi</th>
                <th>Jenis</th>
                <th>Tingkat</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no_pdf = 1;
            if (count($report_data) > 0):
                foreach($report_data as $row):
            ?>
            <tr>
                <td><?php echo $no_pdf++; ?></td>
                <td><?php echo date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                <td><?php echo htmlspecialchars($row['nis']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                <td><?php echo htmlspecialchars($row['nama_prestasi']); ?></td>
                <td><?php echo htmlspecialchars($row['jenis']); ?></td>
                <td><?php echo htmlspecialchars($row['tingkat']); ?></td>
                <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="9" style="text-align: center;">Tidak ada data prestasi sesuai filter.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        <p>[Kota Anda], <?php echo date('d F Y'); ?></p>
        <div class="ttd">
            <p>Pembina Kesiswaan,</p>
            <br><br><br>
            <p class="nama-pejabat"><?php echo htmlspecialchars($pembina_kesiswaan_nama); ?></p>
            <p>NIP. [NIP Pembina]</p>
        </div>
    </div>
</body>
</html>