<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion"> <!-- sb-sidenav-dark DIKEMBALIKAN -->
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link <?php echo ($_GET['action'] ?? 'dashboard') == 'dashboard' ? 'active' : ''; ?>" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <div class="sb-sidenav-menu-heading">Anak Saya</div>

                <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'riwayat_izin_anak' ? 'active' : ''; ?>" href="index.php?action=riwayat_izin_anak">
                    <div class="sb-nav-link-icon"><i class="fas fa-user-clock"></i></div>
                    Riwayat Izin Anak
                </a>

                <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'dokumen_anak' ? 'active' : ''; ?>" href="index.php?action=dokumen_anak">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-alt"></i></div>
                    Dokumen Anak
                </a>

                <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['agenda_kesiswaan']) ? 'active' : ''; ?>" href="index.php?action=agenda_kesiswaan">
                    <div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>
                    Agenda Kesiswaan
                </a>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?>
        </div>
    </nav>
</div>
<div id="layoutSidenav_content">
    <main>