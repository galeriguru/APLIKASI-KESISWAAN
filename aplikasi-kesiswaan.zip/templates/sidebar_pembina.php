<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link <?php echo ($_GET['action'] ?? 'dashboard') == 'dashboard' ? 'active' : ''; ?>" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                
                <div class="sb-sidenav-menu-heading">Manajemen</div>
                <?php
                    $kelas_actions = ['manajemen_kelas', 'tambah_kelas', 'ubah_kelas'];
                    $is_kelas_active = in_array(($_GET['action'] ?? ''), $kelas_actions);
                ?>
                <a class="nav-link <?php echo $is_kelas_active ? 'active' : ''; ?>" href="index.php?action=manajemen_kelas">
                    <div class="sb-nav-link-icon"><i class="fas fa-school"></i></div>
                    Data Kelas
                </a>
                <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['data_siswa', 'tambah_siswa', 'ubah_siswa']) ? 'active' : ''; ?>" href="index.php?action=data_siswa">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Data Siswa
                </a>


                <?php
                    $prestasi_actions = ['prestasi_siswa', 'tambah_prestasi_siswa', 'jenis_prestasi', 'form_jenis_prestasi'];
                    $is_prestasi_active = in_array(($_GET['action'] ?? ''), $prestasi_actions);
                ?>
                <a class="nav-link <?php echo $is_prestasi_active ? '' : 'collapsed'; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePrestasi" aria-expanded="<?php echo $is_prestasi_active ? 'true' : 'false'; ?>" aria-controls="collapsePrestasi">
                    <div class="sb-nav-link-icon"><i class="fas fa-award"></i></div>
                    Prestasi Siswa
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo $is_prestasi_active ? 'show' : ''; ?>" id="collapsePrestasi" aria-labelledby="headingPrestasi" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['prestasi_siswa', 'tambah_prestasi_siswa']) ? 'active' : ''; ?>" href="index.php?action=prestasi_siswa">Daftar Prestasi</a>
                        <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['jenis_prestasi', 'form_jenis_prestasi']) ? 'active' : ''; ?>" href="index.php?action=jenis_prestasi">Jenis Prestasi</a>
                    </nav>
                </div>

                <?php
                    $pelanggaran_actions = ['pelanggaran_siswa', 'tambah_pelanggaran_siswa', 'jenis_pelanggaran', 'form_jenis_pelanggaran'];
                    $is_pelanggaran_active = in_array(($_GET['action'] ?? ''), $pelanggaran_actions);
                ?>
                <a class="nav-link <?php echo $is_pelanggaran_active ? '' : 'collapsed'; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapsePelanggaran" aria-expanded="<?php echo $is_pelanggaran_active ? 'true' : 'false'; ?>" aria-controls="collapsePelanggaran">
                    <div class="sb-nav-link-icon"><i class="fas fa-exclamation-triangle"></i></div>
                    Pelanggaran Siswa
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo $is_pelanggaran_active ? 'show' : ''; ?>" id="collapsePelanggaran" aria-labelledby="headingPelanggaran" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['pelanggaran_siswa', 'tambah_pelanggaran_siswa']) ? 'active' : ''; ?>" href="index.php?action=pelanggaran_siswa">Riwayat Pelanggaran</a>
                        <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['jenis_pelanggaran', 'form_jenis_pelanggaran']) ? 'active' : ''; ?>" href="index.php?action=jenis_pelanggaran">Jenis Pelanggaran</a>
                    </nav>
                </div>

                <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'surat_panggilan' ? 'active' : ''; ?>" href="index.php?action=surat_panggilan">
                    <div class="sb-nav-link-icon"><i class="fas fa-envelope"></i></div>
                    Surat Panggilan
                </a>
                
                <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['agenda_kesiswaan', 'tambah_agenda_kesiswaan', 'ubah_agenda_kesiswaan']) ? 'active' : ''; ?>" href="index.php?action=agenda_kesiswaan">
                    <div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>
                    Agenda Kesiswaan
                </a>

                <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'izin_siswa' ? 'active' : ''; ?>" href="index.php?action=izin_siswa">
                    <div class="sb-nav-link-icon"><i class="fas fa-user-clock"></i></div>
                    Data Izin Siswa
                </a>

                <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'dokumen_siswa' ? 'active' : ''; ?>" href="index.php?action=dokumen_siswa">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-upload"></i></div>
                    Data Berkas Siswa
                </a>


                <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['manajemen_pengguna', 'tambah_pengguna', 'ubah_pengguna']) ? 'active' : ''; ?>" href="index.php?action=manajemen_pengguna">
                    <div class="sb-nav-link-icon"><i class="fas fa-user-cog"></i></div>
                    Data Pengguna
                </a>

                <div class="sb-sidenav-menu-heading">Laporan</div>
                <?php
                    $laporan_actions = ['laporan_prestasi', 'laporan_pelanggaran', 'laporan_surat_panggilan'];
                    $is_laporan_active = in_array(($_GET['action'] ?? ''), $laporan_actions);
                ?>
                <a class="nav-link <?php echo $is_laporan_active ? '' : 'collapsed'; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLaporan" aria-expanded="<?php echo $is_laporan_active ? 'true' : 'false'; ?>" aria-controls="collapseLaporan">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-alt"></i></div>
                    Laporan
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo $is_laporan_active ? 'show' : ''; ?>" id="collapseLaporan" aria-labelledby="headingLaporan" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'laporan_prestasi' ? 'active' : ''; ?>" href="index.php?action=laporan_prestasi">Laporan Prestasi</a>
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'laporan_pelanggaran' ? 'active' : ''; ?>" href="index.php?action=laporan_pelanggaran">Laporan Pelanggaran</a>
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'laporan_surat_panggilan' ? 'active' : ''; ?>" href="index.php?action=laporan_surat_panggilan">Laporan Surat Panggilan</a>
                    </nav>
                </div>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?>
        </div>
    </nav>
</div>
<div id="layoutSidenav_content">
    <main>