<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion"> <!-- sb-sidenav-dark DIKEMBALIKAN -->
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link <?php echo ($_GET['action'] ?? 'dashboard') == 'dashboard' ? 'active' : ''; ?>" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <div class="sb-sidenav-menu-heading">Kesiswaan Saya</div>
                
                <?php
                    $izin_actions_siswa = ['pengajuan_izin', 'riwayat_izin_saya'];
                    $is_izin_active_siswa = in_array(($_GET['action'] ?? ''), $izin_actions_siswa);
                ?>
                <a class="nav-link <?php echo $is_izin_active_siswa ? '' : 'collapsed'; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseIzinSiswa" aria-expanded="<?php echo $is_izin_active_siswa ? 'true' : 'false'; ?>" aria-controls="collapseIzinSiswa">
                    <div class="sb-nav-link-icon"><i class="fas fa-user-clock"></i></div>
                    Izin Siswa
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo $is_izin_active_siswa ? 'show' : ''; ?>" id="collapseIzinSiswa" aria-labelledby="headingIzinSiswa" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'pengajuan_izin' ? 'active' : ''; ?>" href="index.php?action=pengajuan_izin">Pengajuan Izin</a>
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'riwayat_izin_saya' ? 'active' : ''; ?>" href="index.php?action=riwayat_izin_saya">Riwayat Izin Saya</a>
                    </nav>
                </div>

                <?php
                    $dokumen_actions_siswa = ['upload_dokumen_saya', 'daftar_dokumen_saya'];
                    $is_dokumen_active_siswa = in_array(($_GET['action'] ?? ''), $dokumen_actions_siswa);
                ?>
                <a class="nav-link <?php echo $is_dokumen_active_siswa ? '' : 'collapsed'; ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseDokumenSiswa" aria-expanded="<?php echo $is_dokumen_active_siswa ? 'true' : 'false'; ?>" aria-controls="collapseDokumenSiswa">
                    <div class="sb-nav-link-icon"><i class="fas fa-file-upload"></i></div>
                    Dokumen Pengajuan
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse <?php echo $is_dokumen_active_siswa ? 'show' : ''; ?>" id="collapseDokumenSiswa" aria-labelledby="headingDokumenSiswa" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'upload_dokumen_saya' ? 'active' : ''; ?>" href="index.php?action=upload_dokumen_saya">Upload Dokumen</a>
                        <a class="nav-link <?php echo ($_GET['action'] ?? '') == 'daftar_dokumen_saya' ? 'active' : ''; ?>" href="index.php?action=daftar_dokumen_saya">Dokumen Saya</a>
                    </nav>
                </div>

                <a class="nav-link <?php echo in_array(($_GET['action'] ?? ''), ['agenda_kesiswaan']) ? 'active' : ''; ?>" href="index.php?action=agenda_kesiswaan">
                    <div class="sb-nav-link-icon"><i class="fas fa-calendar-alt"></i></div>
                    Agenda Kesiswaan
                </a>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo ucfirst(str_replace('_', ' ', $_SESSION['role'])); ?>
        </div>
    </nav>
</div>
<div id="layoutSidenav_content">
    <main>