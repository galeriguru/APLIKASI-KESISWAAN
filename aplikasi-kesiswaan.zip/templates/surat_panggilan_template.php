<?php
date_default_timezone_set('Asia/Jakarta');

function format_tanggal_indonesia($date_str, $include_day = false) {
    $hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    $timestamp = strtotime($date_str);
    $day_of_week = $hari[date('w', $timestamp)];
    $day_of_month = date('d', $timestamp);
    $month = $bulan[(int)date('n', $timestamp)];
    $year = date('Y', $timestamp);

    $formatted_date = "$day_of_month $month $year";
    if ($include_day) {
        return "$day_of_week, $formatted_date";
    }
    return $formatted_date;
}

function generate_nomor_surat($id_siswa) {
    $kode_surat = '421.3';
    $nama_sekolah_singkat = 'SP';
    $bulan_romawi = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
    $bulan_sekarang = $bulan_romawi[date('n') - 1];
    $tahun_sekarang = date('Y');
    return "{$kode_surat}/{$id_siswa}/{$nama_sekolah_singkat}/{$bulan_sekarang}/{$tahun_sekarang}";
}

$data_siswa = $data;
$nama_pembina = $pembina_kesiswaan_nama;

$nomor_surat = generate_nomor_surat($data_siswa['nis'] ?? '000');
$tanggal_surat_dibuat_str = date('Y-m-d');
$tanggal_surat_dibuat = format_tanggal_indonesia($tanggal_surat_dibuat_str);
$tanggal_panggilan_str = date('Y-m-d', strtotime('+1 day'));
$tanggal_panggilan = format_tanggal_indonesia($tanggal_panggilan_str, true);
$waktu_panggilan = '09:00';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Surat Panggilan Orang Tua - <?php echo htmlspecialchars($data_siswa['nama_siswa']); ?></title>
    <style>
        @page {
            margin: 2cm 2cm 2cm 3cm;
        }
        body { 
            font-family: 'Times New Roman', Times, serif; 
            font-size: 12pt; 
            line-height: 1.3;
            margin: 0;
            padding: 0;
        }
        .kop-surat-image { 
            width: 100%; 
            height: auto; 
            margin-bottom: 15px; 
        }
        .konten p { 
            text-align: justify; 
            margin: 0 0 0.8em 0; 
        }
        .data-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 8px; 
            margin-bottom: 8px; 
        }
        .data-table td { 
            padding: 1px 0; 
            vertical-align: top; 
        }
        .data-table .label { 
            width: 200px; 
        }
        .data-table .separator { 
            width: 15px; 
        }
        .tanda-tangan-table { 
            width: 100%; 
            margin-top: 25px; 
        }
        .tanda-tangan-table td { 
            text-align: center; 
            vertical-align: top; 
            width: 50%; 
        }
        .nama-pejabat { 
            font-weight: bold; 
            text-decoration: underline; 
            padding-top: 60px; 
            display: block; 
        }
    </style>
</head>
<body>
    <img src="<?php echo BASE_URL; ?>/assets/img/kop.png" alt="Kop Surat" class="kop-surat-image">

    <div style="text-align: right; margin-bottom: 20px;">
        <?php echo KOTA_SEKOLAH; ?>, <?php echo $tanggal_surat_dibuat; ?>
    </div>

    <table class="data-table" style="width: auto; margin-top: 0;">
        <tr><td class="label">Nomor</td><td class="separator">:</td><td><?php echo $nomor_surat; ?></td></tr>
        <tr><td class="label">Lampiran</td><td class="separator">:</td><td>-</td></tr>
        <tr><td class="label">Hal</td><td class="separator">:</td><td><b>Panggilan Orang Tua/Wali Siswa</b></td></tr>
    </table>

    <div class="konten">
        <p style="margin-top: 15px;">Yth. Bapak/Ibu Orang Tua/Wali dari Ananda:<br>
        <strong><?php echo htmlspecialchars($data_siswa['nama_siswa']); ?></strong><br>
        di Tempat</p>
        
        <p>Dengan hormat,</p>
        <p>Menindaklanjuti catatan kedisiplinan siswa dari pihak sekolah, dengan ini kami memberitahukan data siswa sebagai berikut:</p>
        
        <table class="data-table" style="margin-left: 30px;">
            <tr><td class="label">Nama</td><td class="separator">:</td><td><strong><?php echo htmlspecialchars($data_siswa['nama_siswa']); ?></strong></td></tr>
            <tr><td class="label">NIS</td><td class="separator">:</td><td><?php echo htmlspecialchars($data_siswa['nis']); ?></td></tr>
            <tr><td class="label">Kelas</td><td class="separator">:</td><td><?php echo htmlspecialchars($data_siswa['nama_kelas']); ?></td></tr>
            <tr><td class="label">Total Poin Pelanggaran</td><td class="separator">:</td><td><strong style="color: red;"><?php echo htmlspecialchars($data_siswa['total_poin_pelanggaran']); ?> Poin</strong></td></tr>
        </table>

        <p>Sehubungan dengan total poin tersebut, kami mengundang Bapak/Ibu untuk hadir di sekolah guna membahas pembinaan lebih lanjut bagi putra/putri Anda pada:</p>

        <table class="data-table" style="margin-left: 30px;">
             <tr><td class="label">Hari, Tanggal</td><td class="separator">:</td><td><b><?php echo $tanggal_panggilan; ?></b></td></tr>
             <tr><td class="label">Pukul</td><td class="separator">:</td><td><?php echo $waktu_panggilan; ?> WIB s.d. selesai</td></tr>
             <tr><td class="label">Tempat</td><td class="separator">:</td><td>Ruang Bimbingan Konseling (BK)</td></tr>
        </table>

        <p>Kehadiran Bapak/Ibu sangat kami harapkan. Atas perhatian dan kerja samanya, kami sampaikan terima kasih.</p>
    </div>

    <table class="tanda-tangan-table">
        <tr>
            <td>
                Mengetahui,<br>
                Kepala Sekolah
                <span class="nama-pejabat"><?php echo NAMA_KEPALA_SEKOLAH; ?></span>
                <span>NIP. <?php echo NIP_KEPALA_SEKOLAH; ?></span>
            </td>
            <td>
                Hormat kami,<br>
                Pembina Kesiswaan
                <span class="nama-pejabat"><?php echo htmlspecialchars($nama_pembina); ?></span>
                <span>NIP. <?php echo NIP_PEMBINA; ?></span>
            </td>
        </tr>
    </table>
</body>
</html>